import 'package:flutter/material.dart';
import 'package:lapor_book/components/styles.dart';

List<String> dataStatus = ['Posted', 'Proses', 'Selesai'];
List<Color> warnaStatus = [warningColor, dangerColor, successColor];
List<String> dataInstansi = ['Pembangunan', 'Jalanan', 'Pendidikan'];
